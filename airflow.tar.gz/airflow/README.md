## Redme for the Project Airflow - Data Engineer Udacity Nanodegree ##  
#Project scope
As a Data Engineer who is working for Sparkify (streaming start up company) we have to build up a Data Warehouse ETL pipline in Apache Airflow. The target is to create a high grade data pipeline that are dynamic and built from reusable tasks and also can be monitored, and allow easy backfills of the datas.

#Used Datasets and Tools 
This project will use Apache Airflow to create a pipeline to extract, transform, and load JSON data from Amazon S3 to Amazon Redshift. The programming language is phython 3.
The used datas are the following ones
 
- Log data: s3://udacity-dend/log_data 
- Song data: s3://udacity-dend/song_data


#Data Pipline and the needed steps

1. Build the following operators and files
- Stage to Redshift Operator : load JSON data from Amazon S3 into staging tables in Amazon Redshift.
- Load Dimension Table Operator : transforms and load data from staging tables to the dimension tables.
- Load Fact Table Operator : transforms and loads data from staging tables to the dimension tables.
- Data Quality Operator: allows for data quality checks against the data once the ETL process has completed
- udac_example_dag : file which runs the pipeline. In Apache Airflow, should these DAG appear. To start the procces thes dag will be enabled in Airfolw. It will be run on a daily basis from 01.09.2018-30.09.2018. 

2. execute the operatiors und run the script
# Performe the script

1. create a cluster in Redshift
2. create tables with a connection to the Redshift cluster with any Postgres client using the Redhsift hostname, username, password, and port and Run > create_tables.sql 
3. run > /opt/airflow/start.s in the workflow console
4. create in Airflow conn_id for Redshift and amazone 
5. swich the Dag to on and trigger it.





